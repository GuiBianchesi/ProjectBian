
package project00;

public class Calcular {
    
   private double salarioBruto;
   private double IR;
   private double salarioLiquido;
   
   public Calcular() { 
   }
   public Calcular(double sb) {
       this.setSalarioBruto(sb);
      
   }
   public double getSalarioBruto(){
       return salarioBruto;
   }
   public void setSalarioBruto(double salarioBruto){
       this.salarioBruto = salarioBruto;
   }
   public void setSalarioLiquido(double salarioLiquido){
       this.salarioLiquido = salarioLiquido;
   }
   public double calculaFGTS(double fgts){
       
   }
   
}
